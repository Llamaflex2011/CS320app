package milestone3;

import java.util.HashMap;
import java.util.Map;

public class ContactService {
    // In-memory database to store contacts using their ID as the key
    private final Map<String, Contact> contacts = new HashMap<>();

    // Adds a contact if it is not null and the ID does not already exist
    public boolean addContact(Contact contact) {
        if (contact == null || contacts.containsKey(contact.getContactId())) {
            return false;
        }
        contacts.put(contact.getContactId(), contact);
        return true;
    }

    // Deletes a contact by ID if it exists in the map
    public boolean deleteContact(String contactId) {
        if (contactId == null || !contacts.containsKey(contactId)) {
            return false;
        }
        contacts.remove(contactId);
        return true;
    }

    // Updates first name; returns false if contact not found or validation fails
    public boolean updateFirstName(String contactId, String firstName) {
        Contact contact = contacts.get(contactId);
        if (contact == null) {
            return false;
        }
        try {
            contact.setFirstName(firstName);
            return true;
        } catch (IllegalArgumentException e) {
            return false;
        }
    }

    // Updates last name; returns false if contact not found or validation fails
    public boolean updateLastName(String contactId, String lastName) {
        Contact contact = contacts.get(contactId);
        if (contact == null) {
            return false;
        }
        try {
            contact.setLastName(lastName);
            return true;
        } catch (IllegalArgumentException e) {
            return false;
        }
    }

    // Updates phone; automatically catches the new 10-digit regex validation rules
    public boolean updatePhone(String contactId, String phone) {
        Contact contact = contacts.get(contactId);
        if (contact == null) {
            return false;
        }
        try {
            contact.setPhone(phone); // This will fail and jump to catch if phone has letters/symbols
            return true;
        } catch (IllegalArgumentException e) {
            return false;
        }
    }

    // Updates address; returns false if contact not found or validation fails
    public boolean updateAddress(String contactId, String address) {
        Contact contact = contacts.get(contactId);
        if (contact == null) {
            return false;
        }
        try {
            contact.setAddress(address);
            return true;
        } catch (IllegalArgumentException e) {
            return false;
        }
    }

    // Retrieves a contact from the map using its ID
    public Contact getContact(String contactId) {
        return contacts.get(contactId);
    }
}

