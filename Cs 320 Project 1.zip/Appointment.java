package milestone3;

import java.util.Date;

public class Appointment {
    // All fields are marked final to ensure complete immutability after construction
    private final String appointmentId;
    private final Date appointmentDate;
    private final String description;

    /**
     * Constructor used to initialize a new Appointment with explicit input validation.
     * 
     * @param appointmentId   The distinct tracking ID (must not be null, max 10 characters)
     * @param appointmentDate The scheduled date (must not be null, cannot be in the past)
     * @param description     The details of the appointment (must not be null, max 50 characters)
     */
    public Appointment(String appointmentId, Date appointmentDate, String description) {
        // Enforce the requirement that the ID cannot be empty or exceed 10 characters
        if (appointmentId == null || appointmentId.length() > 10) {
            throw new IllegalArgumentException("Invalid appointment ID");
        }
        this.appointmentId = appointmentId;

        // Run private helper validations before assigning the values to the final fields
        this.appointmentDate = validateAppointmentDate(appointmentDate);
        this.description = validateDescription(description);
    }

    // --- Accessor Methods (No Setters Allowed Per Requirements) ---

    // Retrieves the appointment's unique ID
    public String getAppointmentId() {
        return appointmentId;
    }

    // Retrieves the scheduled appointment date
    public Date getAppointmentDate() {
        return appointmentDate;
    }

    // Retrieves the appointment details
    public String getDescription() {
        return description;
    }

    // --- Private Validation Helpers ---

    /**
     * Validates the date input to ensure it is not null and not in the past.
     * 
     * @param appointmentDate The input date to test
     * @return The validated Date object
     */
    private Date validateAppointmentDate(Date appointmentDate) {
        if (appointmentDate == null) {
            throw new IllegalArgumentException("Appointment date cannot be null");
        }
        // Enforce that the date cannot be in the past compared to the current system time
        if (appointmentDate.before(new Date())) {
            throw new IllegalArgumentException("Appointment date cannot be in the past");
        }
        return appointmentDate;
    }

    /**
     * Validates the description input to ensure it is not null and fits the size constraints.
     * 
     * @param description The input description text to test
     * @return The validated description string
     */
    private String validateDescription(String description) {
        if (description == null || description.length() > 50) {
            throw new IllegalArgumentException("Invalid appointment description");
        }
        return description;
    }
}

