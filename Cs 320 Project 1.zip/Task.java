package milestone3;

public class Task {
    // Immutable field: Once assigned, the task ID cannot be altered
    private final String taskId; 
    private String name;
    private String description;

    /**
     * Constructor used to initialize a new Task instance with explicit input validation.
     * 
     * @param taskId      The distinct tracking ID (must not be null, max 10 characters)
     * @param name        The name assigned to the task (must not be null, max 20 characters)
     * @param description The textual details of the task (must not be null, max 50 characters)
     */
    public Task(String taskId, String name, String description) {
        // Enforce the requirement that the task ID cannot be empty or exceed 10 characters
        if (taskId == null || taskId.length() > 10) {
            throw new IllegalArgumentException("Invalid task ID");
        }
        this.taskId = taskId;

        // Delegate field initialization to setters to leverage existing validation checks
        setName(name);
        setDescription(description);
    }

    // --- Accessor and Mutator Methods ---

    // Retrieves the task's unique ID
    public String getTaskId() {
        return taskId;
    }

    // Retrieves the task's name
    public String getName() {
        return name;
    }

    /**
     * Updates the name field if the input satisfies all length and null constraints.
     * 
     * @param name The new name string
     */
    public void setName(String name) {
        // Enforce the requirement that the name cannot be empty or exceed 20 characters
        if (name == null || name.length() > 20) {
            throw new IllegalArgumentException("Invalid task name");
        }
        this.name = name;
    }

    // Retrieves the task's description text
    public String getDescription() {
        return description;
    }

    /**
     * Updates the description field if the input satisfies all length and null constraints.
     * 
     * @param description The new description string
     */
    public void setDescription(String description) {
        // Enforce the requirement that the description cannot be empty or exceed 50 characters
        if (description == null || description.length() > 50) {
            throw new IllegalArgumentException("Invalid task description");
        }
        this.description = description;
    }
}
