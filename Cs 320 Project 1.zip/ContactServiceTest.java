package milestone3;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class ContactServiceTest {
    private ContactService service;

    // Sets up a fresh service instance before running every individual test
    @BeforeEach
    public void setUp() {
        service = new ContactService();
    }

    // Tests that a valid contact is successfully added and can be found
    @Test
    public void testAddContactSuccess() {
        Contact contact = new Contact("1", "Nick", "Steel", "9876543210", "456 Oak Ave");
        assertTrue(service.addContact(contact));
        assertEquals(contact, service.getContact("1"));
    }

    // Tests that adding a second contact with a duplicate ID returns false
    @Test
    public void testAddDuplicateContactIdFails() {
        Contact contact1 = new Contact("1", "Nick", "Steel", "9876543210", "456 Oak Ave");
        Contact contact2 = new Contact("1", "Bob", "Jones", "5556667777", "789 Pine Rd");
        assertTrue(service.addContact(contact1));
        assertFalse(service.addContact(contact2));
    }

    // Tests that an existing contact is removed and can no longer be retrieved
    @Test
    public void testDeleteContactSuccess() {
        Contact contact = new Contact("1", "Nick", "Steel", "9876543210", "456 Oak Ave");
        service.addContact(contact);
        assertTrue(service.deleteContact("1"));
        assertNull(service.getContact("1"));
    }

    // Tests that attempting to delete an ID that does not exist returns false
    @Test
    public void testDeleteNonExistentContactFails() {
        assertFalse(service.deleteContact("999"));
    }

    // Tests updating a contact's first name successfully
    @Test
    public void testUpdateFirstNameSuccess() {
        Contact contact = new Contact("1", "Nick", "Steel", "9876543210", "456 Oak Ave");
        service.addContact(contact);
        assertTrue(service.updateFirstName("1", "Jeff"));
        assertEquals("Jeff", service.getContact("1").getFirstName());
    }

    // Tests updating a contact's last name successfully
    @Test
    public void testUpdateLastNameSuccess() {
        Contact contact = new Contact("1", "Nick", "Steel", "9876543210", "456 Oak Ave");
        service.addContact(contact);
        assertTrue(service.updateLastName("1", "Green"));
        assertEquals("Green", service.getContact("1").getLastName());
    }

    // Tests updating a contact's phone number successfully with valid data
    @Test
    public void testUpdatePhoneSuccess() {
        Contact contact = new Contact("1", "Nick", "Steel", "9876543210", "456 Oak Ave");
        service.addContact(contact);
        assertTrue(service.updatePhone("1", "1112223333"));
        assertEquals("1112223333", service.getContact("1").getPhone());
    }

    // Tests updating a contact's address successfully
    @Test
    public void testUpdateAddressSuccess() {
        Contact contact = new Contact("1", "Nick", "Steel", "9876543210", "456 Oak Ave");
        service.addContact(contact);
        assertTrue(service.updateAddress("1", "789 Oak St"));
        assertEquals("789 Oak St", service.getContact("1").getAddress());
    }

    // Tests that sending bad data (like text too long or wrong length) returns false
    @Test
    public void testUpdateFieldWithInvalidDataFails() {
        Contact contact = new Contact("1", "Nick", "Steel", "9876543210", "456 Oak Ave");
        service.addContact(contact);
        assertFalse(service.updateFirstName("1", "ReallyBigLargeFirstName")); // Too long
        assertFalse(service.updatePhone("1", "123")); // Too short
    }

    // Tests that phone numbers with letters or punctuation are rejected by our regex logic
    @Test
    public void testUpdatePhoneWithNonDigitsFails() {
        Contact contact = new Contact("1", "Nick", "Steel", "9876543210", "456 Oak Ave");
        service.addContact(contact);
        assertFalse(service.updatePhone("1", "ABCDEFGHIJ")); // Contains letters
        assertFalse(service.updatePhone("1", "123-456789")); // Contains dash character
    }
}

