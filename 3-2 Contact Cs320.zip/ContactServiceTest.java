package milestone3;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class ContactServiceTest {
    private ContactService service;

    @BeforeEach
    public void setUp() {
        service = new ContactService();
    }

    @Test
    public void testAddContactSuccess() {
        Contact contact = new Contact("1", "Nick", "Steel", "9876543210", "456 Oak Ave");
        assertTrue(service.addContact(contact));
        assertEquals(contact, service.getContact("1"));
    }

    @Test
    public void testAddDuplicateContactIdFails() {
        Contact contact1 = new Contact("1", "Nick", "Steel", "9876543210", "456 Oak Ave");
        Contact contact2 = new Contact("1", "Bob", "Jones", "5556667777", "789 Pine Rd");
        assertTrue(service.addContact(contact1));
        assertFalse(service.addContact(contact2));
    }

    @Test
    public void testDeleteContactSuccess() {
        Contact contact = new Contact("1", "Nick", "Steel", "9876543210", "456 Oak Ave");
        service.addContact(contact);
        assertTrue(service.deleteContact("1"));
        assertNull(service.getContact("1"));
    }

    @Test
    public void testDeleteNonExistentContactFails() {
        assertFalse(service.deleteContact("999"));
    }

    @Test
    public void testUpdateFirstNameSuccess() {
        Contact contact = new Contact("1", "Nick", "Steel", "9876543210", "456 Oak Ave");
        service.addContact(contact);
        assertTrue(service.updateFirstName("1", "Jeff"));
        assertEquals("Jeff", service.getContact("1").getFirstName());
    }

    @Test
    public void testUpdateLastNameSuccess() {
        Contact contact = new Contact("1", "Nick", "Steel", "9876543210", "456 Oak Ave");
        service.addContact(contact);
        assertTrue(service.updateLastName("1", "Green"));
        assertEquals("Green", service.getContact("1").getLastName());
    }

    @Test
    public void testUpdatePhoneSuccess() {
        Contact contact = new Contact("1", "Nick", "Steel", "9876543210", "456 Oak Ave");
        service.addContact(contact);
        assertTrue(service.updatePhone("1", "1112223333"));
        assertEquals("1112223333", service.getContact("1").getPhone());
    }

    @Test
    public void testUpdateAddressSuccess() {
        Contact contact = new Contact("1", "Nick", "Steel", "9876543210", "456 Oak Ave");
        service.addContact(contact);
        assertTrue(service.updateAddress("1", "789 Oak St"));
        assertEquals("789 Oak St", service.getContact("1").getAddress());
    }

    @Test
    public void testUpdateFieldWithInvalidDataFails() {
        Contact contact = new Contact("1", "Nick", "Steel", "9876543210", "456 Oak Ave");
        service.addContact(contact);
        assertFalse(service.updateFirstName("1", "ReallyBigLargeFirstName"));
        assertFalse(service.updatePhone("1", "123"));
    }
}

