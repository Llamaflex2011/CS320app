package milestone3;

import java.util.HashMap;
import java.util.Map;

public class AppointmentService {
    // In-memory data store mapping Appointment IDs directly to their corresponding objects
    private final Map<String, Appointment> appointments = new HashMap<>();

    /**
     * Inserts a unique appointment object into the in-memory data registry.
     * 
     * @param appointment The initialized appointment object to persist
     */
    public void addAppointment(Appointment appointment) {
        // Verify that the appointment instance is not null
        if (appointment == null) {
            throw new IllegalArgumentException("Appointment cannot be null");
        }
        // Verify that the appointment ID does not conflict with an existing entry
        if (appointments.containsKey(appointment.getAppointmentId())) {
            throw new IllegalArgumentException("Appointment ID must be unique");
        }
        appointments.put(appointment.getAppointmentId(), appointment);
    }

    /**
     * Removes an existing appointment object from the collection using its ID.
     * 
     * @param appointmentId The target identifier to be deleted
     */
    public void deleteAppointment(String appointmentId) {
        // Verify that the requested ID is valid and present in the collection
        if (appointmentId == null || !appointments.containsKey(appointmentId)) {
            throw new IllegalArgumentException("Appointment ID not found");
        }
        appointments.remove(appointmentId);
    }

    /**
     * Retrieves an appointment object using its ID (utilized for verification within unit tests).
     * 
     * @param appointmentId The targeted search identifier
     * @return The matching Appointment instance, or null if it cannot be found
     */
    
    public Appointment getAppointment(String appointmentId) {
        return appointments.get(appointmentId);
    }
}

