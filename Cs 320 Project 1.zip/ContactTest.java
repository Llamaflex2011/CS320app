package milestone3;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class ContactTest {

    // Tests that a valid contact is created properly when all data is correct
    @Test
    public void testContactCreationSuccess() {
        Contact contact = new Contact("12345", "Nick", "Woo", "1234567890", "123 Oak St");
        assertEquals("12345", contact.getContactId());
        assertEquals("Nick", contact.getFirstName());
        assertEquals("Woo", contact.getLastName());
        assertEquals("1234567890", contact.getPhone());
        assertEquals("123 Oak St", contact.getAddress());
    }

    // ID must fail if it is over 10 characters long
    @Test
    public void testContactIdTooLong() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345678901", "Nick", "Woo", "1234567890", "123 Oak St");
        });
    }

    // ID must fail if it is null
    @Test
    public void testContactIdNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact(null, "Nick", "Woo", "1234567890", "123 Oak St");
        });
    }

    // First name must fail if it is over 10 characters long
    @Test
    public void testFirstNameTooLong() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345", "NickNickNick", "Woo", "1234567890", "123 Oak St");
        });
    }

    // First name must fail if it is null
    @Test
    public void testFirstNameNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345", null, "Woo", "1234567890", "123 Oak St");
        });
    }

    // Last name must fail if it is over 10 characters long
    @Test
    public void testLastNameTooLong() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345", "Nick", "WooWooWooWoo", "1234567890", "123 Oak St");
        });
    }

    // Last name must fail if it is null
    @Test
    public void testLastNameNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345", "Nick", null, "1234567890", "123 Oak St");
        });
    }

    // Phone must fail if it is not exactly 10 characters long
    @Test
    public void testPhoneIncorrectLength() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345", "Nick", "Woo", "12345", "123 Oak St");
        });
    }

    // Phone must fail if it is null
    @Test
    public void testPhoneNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345", "Nick", "Woo", null, "123 Oak St");
        });
    }

    // Phone must fail if it contains letters or punctuation symbols (our regex fix)
    @Test
    public void testPhoneContainsNonDigits() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345", "Nick", "Woo", "ABCDEFGHIJ", "123 Oak St");
        });
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345", "Nick", "Woo", "123-456789", "123 Oak St");
        });
    }

    // Address must fail if it is over 30 characters long
    @Test
    public void testAddressTooLong() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345", "Nick", "Woo", "1234567890", "123 Oak Street Way Avenue Boulevard");
        });
    }

    // Address must fail if it is null
    @Test
    public void testAddressNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345", "Nick", "Woo", "1234567890", null);
        });
    }

    // Verifies that setters successfully update values when using valid data
    @Test
    public void testSettersSuccess() {
        Contact contact = new Contact("12345", "Nick", "Woo", "1234567890", "123 Oak St");
        contact.setFirstName("Bob");
        contact.setLastName("Smith");
        contact.setPhone("0987654321");
        contact.setAddress("789 Pine Rd");
        
        assertEquals("Bob", contact.getFirstName());
        assertEquals("Smith", contact.getLastName());
        assertEquals("0987654321", contact.getPhone());
        assertEquals("789 Pine Rd", contact.getAddress());
    }

    // Verifies that setters block bad inputs (null, wrong length, bad formats)
    @Test
    public void testSettersValidationFails() {
        Contact contact = new Contact("12345", "Nick", "Woo", "1234567890", "123 Oak St");
        
        // Test first name errors
        assertThrows(IllegalArgumentException.class, () -> contact.setFirstName("ReallyLongFirstName"));
        assertThrows(IllegalArgumentException.class, () -> contact.setFirstName(null));
        
        // Test last name errors
        assertThrows(IllegalArgumentException.class, () -> contact.setLastName("ReallyLongLastName"));
        assertThrows(IllegalArgumentException.class, () -> contact.setLastName(null));
        
        // Test phone errors
        assertThrows(IllegalArgumentException.class, () -> contact.setPhone("123")); 
        assertThrows(IllegalArgumentException.class, () -> contact.setPhone("ABCDEFGHIJ")); 
        assertThrows(IllegalArgumentException.class, () -> contact.setPhone(null));
        
        // Test address errors
        assertThrows(IllegalArgumentException.class, () -> contact.setAddress("This address string is way too long for validation"));
        assertThrows(IllegalArgumentException.class, () -> contact.setAddress(null));
    }
}
