package milestone3;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class TaskServiceTest {

    private TaskService service;
    private Task task;

    // Sets up a fresh service and task instance before every test
    @BeforeEach
    void setUp() {
        service = new TaskService();
        task = new Task("T1", "Name", "Description");
    }

    // --- Core Add Operations ---

    // Verifies adding a valid task works correctly
    @Test
    void testAddTaskSuccess() {
        service.addTask(task);
        assertNotNull(service.getTask("T1"));
    }

    // Verifies adding a task with an existing ID throws an error
    @Test
    void testAddTaskDuplicateIdThrowsException() {
        service.addTask(task);
        assertThrows(IllegalArgumentException.class, () -> service.addTask(task));
    }

    // Verifies passing a null task object throws an error
    @Test
    void testAddTaskNullThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> service.addTask(null));
    }

    // --- Core Delete Operations ---

    // Verifies removing a task works correctly
    @Test
    void testDeleteTaskSuccess() {
        service.addTask(task);
        service.deleteTask("T1");
        assertNull(service.getTask("T1"));
    }

    // Verifies deleting a non-existent task ID throws an error
    @Test
    void testDeleteTaskNotFoundThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> service.deleteTask("T1"));
    }

    // Verifies passing a null task ID for deletion throws an error
    @Test
    void testDeleteTaskNullIdThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> service.deleteTask(null));
    }

    // --- Name Update Operations ---
    
    // Verifies successfully changing only the task name
    @Test
    void testUpdateTaskNameByIdSuccess() {
        service.addTask(task);
        service.updateTaskNameById("T1", "New Name");
        assertEquals("New Name", service.getTask("T1").getName());
        assertEquals("Description", service.getTask("T1").getDescription()); // Unchanged field
    }

    // Verifies updating name for a missing task ID throws an error
    @Test
    void testUpdateTaskNameByIdNotFound() {
        assertThrows(IllegalArgumentException.class, () -> service.updateTaskNameById("MissingID", "New Name"));
    }

    // Verifies passing a null task ID for name update throws an error
    @Test
    void testUpdateTaskNameByIdNullId() {
        assertThrows(IllegalArgumentException.class, () -> service.updateTaskNameById(null, "New Name"));
    }

    // Verifies updating name to null fails and leaves original name intact
    @Test
    void testUpdateTaskNameByIdNullNameThrowsAndRetainsState() {
        service.addTask(task);
        assertThrows(IllegalArgumentException.class, () -> service.updateTaskNameById("T1", null));
        assertEquals("Name", service.getTask("T1").getName()); // Retained state
    }

    // Verifies updating name to >20 characters fails and leaves original name intact
    @Test
    void testUpdateTaskNameByIdTooLongThrowsAndRetainsState() {
        service.addTask(task);
        assertThrows(IllegalArgumentException.class, () -> service.updateTaskNameById("T1", "123456789012345678901"));
        assertEquals("Name", service.getTask("T1").getName()); // Retained state
    }

    // --- Description Update Operations ---

    // Verifies successfully changing only the task description
    @Test
    void testUpdateTaskDescriptionByIdSuccess() {
        service.addTask(task);
        service.updateTaskDescriptionById("T1", "New Description");
        assertEquals("New Description", service.getTask("T1").getDescription());
        assertEquals("Name", service.getTask("T1").getName()); // Unchanged field
    }

    // Verifies updating description for a missing task ID throws an error
    @Test
    void testUpdateTaskDescriptionByIdNotFound() {
        assertThrows(IllegalArgumentException.class, () -> service.updateTaskDescriptionById("MissingID", "New Desc"));
    }

    // Verifies passing a null task ID for description update throws an error
    @Test
    void testUpdateTaskDescriptionByIdNullId() {
        assertThrows(IllegalArgumentException.class, () -> service.updateTaskDescriptionById(null, "New Desc"));
    }

    // Verifies updating description to null fails and leaves original description intact
    @Test
    void testUpdateTaskDescriptionByIdNullDescThrowsAndRetainsState() {
        service.addTask(task);
        assertThrows(IllegalArgumentException.class, () -> service.updateTaskDescriptionById("T1", null));
        assertEquals("Description", service.getTask("T1").getDescription()); // Retained state
    }

    // Verifies updating description to >50 characters fails and leaves original description intact
    @Test
    void testUpdateTaskDescriptionByIdTooLongThrowsAndRetainsState() {
        service.addTask(task);
        String longDesc = "123456789012345678901234567890123456789012345678901";
        assertThrows(IllegalArgumentException.class, () -> service.updateTaskDescriptionById("T1", longDesc));
        assertEquals("Description", service.getTask("T1").getDescription()); // Retained state
    }
}
