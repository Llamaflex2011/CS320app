package milestone3;

import java.util.HashMap;
import java.util.Map;

public class TaskService {
    // In-memory data store mapping Task IDs directly to their corresponding Task objects
    private final Map<String, Task> tasks = new HashMap<>();

    /**
     * Inserts a unique task object into the in-memory data registry.
     * 
     * @param task The initialized task object to persist
     */
    public void addTask(Task task) {
        // Verify that the task instance being added is not null
        if (task == null) {
            throw new IllegalArgumentException("Task cannot be null");
        }
        // Verify that the task ID does not conflict with an existing entry
        if (tasks.containsKey(task.getTaskId())) {
            throw new IllegalArgumentException("Task ID must be unique");
        }
        tasks.put(task.getTaskId(), task);
    }

    /**
     * Removes an existing task object from the collection using its ID.
     * 
     * @param taskId The target identifier of the task to be deleted
     */
    public void deleteTask(String taskId) {
        // Verify that the requested ID is valid and present in the collection
        if (taskId == null || !tasks.containsKey(taskId)) {
            throw new IllegalArgumentException("Task ID not found");
        }
        tasks.remove(taskId);
    }

    /**
     * Pinpoints a task by ID and updates only its name attribute.
     * 
     * @param taskId The identifier of the task to locate
     * @param name   The new name string to apply
     */
    public void updateTaskNameById(String taskId, String name) {
        // Verify that the requested ID is valid and present in the collection
        if (taskId == null || !tasks.containsKey(taskId)) {
            throw new IllegalArgumentException("Task ID not found");
        }
        // Fetch the object reference and call its setter, triggering class validations
        Task task = tasks.get(taskId);
        task.setName(name); 
    }

    /**
     * Pinpoints a task by ID and updates only its description attribute.
     * 
     * @param taskId      The identifier of the task to locate
     * @param description The new description string to apply
     */
    public void updateTaskDescriptionById(String taskId, String description) {
        // Verify that the requested ID is valid and present in the collection
        if (taskId == null || !tasks.containsKey(taskId)) {
            throw new IllegalArgumentException("Task ID not found");
        }
        // Fetch the object reference and call its setter, triggering class validations
        Task task = tasks.get(taskId);
        task.setDescription(description); 
    }

    /**
     * Retrieves a task object using its ID (primarily utilized for verification within unit tests).
     * 
     * @param taskId The targeted search identifier
     * @return The matching Task instance, or null if it cannot be found
     */
    public Task getTask(String taskId) {
        return tasks.get(taskId);
    }
}
