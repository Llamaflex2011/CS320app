package milestone3;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

class TaskTest {

    // --- Constructor Success Test ---
    
    // Verifies that a task can be successfully created when all initial inputs are valid
    @Test
    void testTaskConstructorSuccess() {
        Task task = new Task("1234567890", "Valid Name", "Valid Description");
        assertEquals("1234567890", task.getTaskId());
        assertEquals("Valid Name", task.getName());
        assertEquals("Valid Description", task.getDescription());
    }

    // --- Task ID Validation Tests ---
    
    // Verifies that a null task ID throws an error during initialization
    @Test
    void testTaskIdNullThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> new Task(null, "Name", "Desc"));
    }

    // Verifies that a task ID longer than 10 characters throws an error during initialization
    @Test
    void testTaskIdTooLongThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> new Task("12345678901", "Name", "Desc"));
    }

    // --- Name Validation Tests (Constructor) ---
    
    // Verifies that a null name throws an error during initial construction
    @Test
    void testTaskNameNullThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> new Task("1", null, "Desc"));
    }

    // Verifies that a name longer than 20 characters throws an error during initial construction
    @Test
    void testTaskNameTooLongThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> new Task("1", "123456789012345678901", "Desc"));
    }

    // --- Description Validation Tests (Constructor) ---
    
    // Verifies that a null description throws an error during initial construction
    @Test
    void testTaskDescriptionNullThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> new Task("1", "Name", null));
    }

    // Verifies that a description longer than 50 characters throws an error during initial construction
    @Test
    void testTaskDescriptionTooLongThrowsException() {
        String longDesc = "123456789012345678901234567890123456789012345678901";
        assertThrows(IllegalArgumentException.class, () -> new Task("1", "Name", longDesc));
    }

    // --- Setter Method Tests: Valid Updates ---
    
    // Verifies that valid strings successfully modify the name and description fields
    @Test
    void testSetNameAndDescriptionSuccess() {
        Task task = new Task("1", "Homework", "Finish CS320 milestone");
        
        task.setName("New Name");
        assertEquals("New Name", task.getName());
        
        task.setDescription("New Description");
        assertEquals("New Description", task.getDescription());
    }

    // --- Setter Method Tests: Invalid Updates (State Retention Checks) ---
    
    // Verifies that setting a name to null fails and keeps the previous valid name intact
    @Test
    void testSetNameNullThrowsException() {
        Task task = new Task("1", "Homework", "Finish CS320 milestone");

        assertThrows(IllegalArgumentException.class, () -> task.setName(null));
        assertEquals("Homework", task.getName()); // Verifies state retention
    }

    // Verifies that setting a name longer than 20 characters fails and keeps the previous valid name intact
    @Test
    void testSetNameTooLongThrowsException() {
        Task task = new Task("1", "Homework", "Finish CS320 milestone");

        assertThrows(IllegalArgumentException.class, () -> task.setName("123456789012345678901"));
        assertEquals("Homework", task.getName()); // Verifies state retention
    }

    // Verifies that setting a description to null fails and keeps the previous valid description intact
    @Test
    void testSetDescriptionNullThrowsException() {
        Task task = new Task("1", "Homework", "Finish CS320 milestone");

        assertThrows(IllegalArgumentException.class, () -> task.setDescription(null));
        assertEquals("Finish CS320 milestone", task.getDescription()); // Verifies state retention
    }

    // Verifies that setting a description longer than 50 characters fails and keeps the previous valid description intact
    @Test
    void testSetDescriptionTooLongThrowsException() {
        Task task = new Task("1", "Homework", "Finish CS320 milestone");
        String longDesc = "123456789012345678901234567890123456789012345678901";

        assertThrows(IllegalArgumentException.class, () -> task.setDescription(longDesc));
        assertEquals("Finish CS320 milestone", task.getDescription()); // Verifies state retention
    }
}
