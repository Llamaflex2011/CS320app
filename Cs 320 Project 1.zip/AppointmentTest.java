package milestone3;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import java.util.Date;

class AppointmentTest {

    // Helper method to create a valid date (exactly 24 hours into the future)
    private Date getFutureDate() {
        return new Date(System.currentTimeMillis() + 86400000); 
    }

    // Helper method to create an invalid historical date (exactly 24 hours in the past)
    private Date getPastDate() {
        return new Date(System.currentTimeMillis() - 86400000); 
    }

    // --- Constructor Success Test ---

    // Verifies that an appointment can be created successfully when all parameters are valid
    @Test
    void testAppointmentConstructorSuccess() {
        Date future = getFutureDate();
        Appointment appt = new Appointment("A1", future, "Valid Description");
        assertEquals("A1", appt.getAppointmentId());
        assertEquals(future, appt.getAppointmentDate());
        assertEquals("Valid Description", appt.getDescription());
    }

    // --- Appointment ID Validation Tests ---

    // Verifies that a null or overly long appointment ID throws an error during initial construction
    @Test
    void testAppointmentIdNullOrTooLong() {
        Date future = getFutureDate();
        assertThrows(IllegalArgumentException.class, () -> new Appointment(null, future, "Desc"));
        assertThrows(IllegalArgumentException.class, () -> new Appointment("12345678901", future, "Desc"));
    }

    // --- Date Validation Tests (Constructor) ---

    // Verifies that a null date or a date in the past throws an error during initial construction
    @Test
    void testAppointmentDateNullOrPast() {
        assertThrows(IllegalArgumentException.class, () -> new Appointment("A1", null, "Desc"));
        assertThrows(IllegalArgumentException.class, () -> new Appointment("A1", getPastDate(), "Desc"));
    }

    // --- Description Validation Tests (Constructor) ---

    // Verifies that a null or overly long description throws an error during initial construction
    @Test
    void testAppointmentDescriptionNullOrTooLong() {
        Date future = getFutureDate();
        assertThrows(IllegalArgumentException.class, () -> new Appointment("A1", future, null));
        String longDesc = "123456789012345678901234567890123456789012345678901"; // 51 characters
        assertThrows(IllegalArgumentException.class, () -> new Appointment("A1", future, longDesc));
    }
}
