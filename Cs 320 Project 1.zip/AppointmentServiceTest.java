package milestone3;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.util.Date;

class AppointmentServiceTest {

    private AppointmentService service;
    private Appointment appointment;

    // Sets up a fresh service and a valid appointment instance before every test
    @BeforeEach
    void setUp() {
        service = new AppointmentService();
        Date futureDate = new Date(System.currentTimeMillis() + 86400000); // 1 day in future
        appointment = new Appointment("A1", futureDate, "Valid Description");
    }

    // --- Core Add Operations ---

    // Verifies adding a valid appointment works correctly and saves to memory
    @Test
    void testAddAppointmentSuccess() {
        service.addAppointment(appointment);
        assertNotNull(service.getAppointment("A1")); // Uses corrected method name
    }

    // Verifies adding an appointment with an existing ID throws an error
    @Test
    void testAddAppointmentDuplicateIdThrowsException() {
        service.addAppointment(appointment);
        assertThrows(IllegalArgumentException.class, () -> service.addAppointment(appointment));
    }

    // Verifies passing a null appointment object throws an error
    @Test
    void testAddAppointmentNullThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> service.addAppointment(null));
    }

    // --- Core Delete Operations ---

    // Verifies removing an appointment works correctly
    @Test
    void testDeleteAppointmentSuccess() {
        service.addAppointment(appointment);
        service.deleteAppointment("A1");
        assertNull(service.getAppointment("A1")); // Uses corrected method name
    }

    // Verifies deleting a non-existent appointment ID throws an error
    @Test
    void testDeleteAppointmentNotFoundThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> service.deleteAppointment("NonExistent"));
    }

    // Verifies passing a null appointment ID for deletion throws an error
    @Test
    void testDeleteAppointmentNullIdThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> service.deleteAppointment(null));
    }
}
