package milestone3;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class ContactTest {

    @Test
    public void testContactCreationSuccess() {
        Contact contact = new Contact("12345", "Nick", "Woo", "1234567890", "123 Oak St");
        assertEquals("12345", contact.getContactId());
        assertEquals("Nick", contact.getFirstName());
        assertEquals("Woo", contact.getLastName());
        assertEquals("1234567890", contact.getPhone());
        assertEquals("123 Oak St", contact.getAddress());
    }

    @Test
    public void testContactIdTooLong() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345678901", "Nick", "Woo", "1234567890", "123 Oak St");
        });
    }

    @Test
    public void testContactIdNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact(null, "Nick", "Woo", "1234567890", "123 Oak St");
        });
    }

    @Test
    public void testFirstNameTooLong() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345", "NickNickNick", "Woo", "1234567890", "123 Oak St");
        });
    }

    @Test
    public void testFirstNameNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345", null, "Woo", "1234567890", "123 Oak St");
        });
    }

    @Test
    public void testLastNameTooLong() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345", "Nick", "WooWooWooWoo", "1234567890", "123 Oak St");
        });
    }

    @Test
    public void testLastNameNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345", "Nick", null, "1234567890", "123 Oak St");
        });
    }

    @Test
    public void testPhoneIncorrectLength() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345", "Nick", "Woo", "12345", "123 Oak St");
        });
    }

    @Test
    public void testPhoneNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345", "Nick", "Woo", null, "123 Oak St");
        });
    }

    @Test
    public void testAddressTooLong() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345", "Nick", "Woo", "1234567890", "123 Oak Street Way Avenue Boulevard");
        });
    }

    @Test
    public void testAddressNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345", "Nick", "Woo", "1234567890", null);
        });
    }
}
