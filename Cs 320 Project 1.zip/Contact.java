package milestone3;

public class Contact {
    // Class variables
    private final String contactId; // final means this cannot be changed later
    private String firstName;
    private String lastName;
    private String phone;
    private String address;

    // Constructor to build a new Contact
    public Contact(String contactId, String firstName, String lastName, String phone, String address) {
        // Validate and set the ID (must not be null, max 10 characters)
        if (contactId == null || contactId.length() > 10) {
            throw new IllegalArgumentException("Invalid contact ID");
        }
        this.contactId = contactId;

        // Use setters to validate and set the remaining fields
        setFirstName(firstName);
        setLastName(lastName);
        setPhone(phone);
        setAddress(address);
    }

    // Getters and Setters
    public String getContactId() {
        return contactId;
    }

    public String getFirstName() {
        return firstName;
    }

    // First name must not be null and max 10 characters
    public void setFirstName(String firstName) {
        if (firstName == null || firstName.length() > 10) {
            throw new IllegalArgumentException("Invalid first name");
        }
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    // Last name must not be null and max 10 characters
    public void setLastName(String lastName) {
        if (lastName == null || lastName.length() > 10) {
            throw new IllegalArgumentException("Invalid last name");
        }
        this.lastName = lastName;
    }

    public String getPhone() {
        return phone;
    }

    // Phone must not be null and must be exactly 10 digits (0-9)
    // \\d{10} means exactly 10 numbers. Letters or symbols will fail.
    public void setPhone(String phone) {
        if (phone == null || !phone.matches("\\d{10}")) {
            throw new IllegalArgumentException("Invalid phone number");
        }
        this.phone = phone;
    }

    public String getAddress() {
        return address;
    }

    // Address must not be null and max 30 characters
    public void setAddress(String address) {
        if (address == null || address.length() > 30) {
            throw new IllegalArgumentException("Invalid address");
        }
        this.address = address;
    }
}

